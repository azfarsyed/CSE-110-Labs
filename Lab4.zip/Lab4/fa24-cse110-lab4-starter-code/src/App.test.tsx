import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import App from './App';
//import AddExpenseForm from './components/Expense/AddExpenseForm';
import { AppProvider } from './context/AppContext';
import {MyBudgetTracker} from './views/MyBudgetTracker'; 
import { useContext } from "react";
import { AppContext } from "./context/AppContext";


describe('Expense Tracker Tests', () => {
  beforeEach(() => {
    render(
      <AppProvider>
        <MyBudgetTracker />
      </AppProvider>
    );


  });

  test("Create an Expense", () => { 
    
    const nameInput = screen.getByLabelText(/name/i);
    const costInput = screen.getByLabelText(/cost/i);
    const addButton = screen.getByRole('button', { name: /save/i });

    fireEvent.change(nameInput, { target: { value: 'Nintendo' } });
    fireEvent.change(costInput, { target: { value: '300' } });
    fireEvent.click(addButton);

    expect(screen.getByText(/nintendo/i)).toBeInTheDocument(); 
    expect(screen.getByText(/remaining: \$700/i)).toBeInTheDocument(); 
    expect(screen.getByText(/spent so far: \$300/i)).toBeInTheDocument(); 

  });

  test("Delete an Expense", () => { 
    const nameInput = screen.getByLabelText(/name/i);
    const costInput = screen.getByLabelText(/cost/i);
    const addButton = screen.getByRole('button', { name: /save/i });

    fireEvent.change(nameInput, { target: { value: 'Nintendo' } });
    fireEvent.change(costInput, { target: { value: '300' } });
    fireEvent.click(addButton);

    expect(screen.getByText(/nintendo/i)).toBeInTheDocument(); 
    expect(screen.getByText(/remaining: \$700/i)).toBeInTheDocument(); 
    expect(screen.getByText(/spent so far: \$300/i)).toBeInTheDocument(); 

    const deleteButton = screen.getByRole('button', { name: /x/i });
    fireEvent.click(deleteButton);

    expect(screen.queryByText(/Nintendo/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/remaining:\$0/i)).not.toBeInTheDocument();
    expect(screen.getByText(/spent so far: \$0/i)).toBeInTheDocument(); 
  }); 

  test("Budget Verification", () => { 
    const nameInput = screen.getByLabelText(/name/i);
    const costInput = screen.getByLabelText(/cost/i);
    const addButton = screen.getByRole('button', { name: /save/i });

    fireEvent.change(nameInput, { target: { value: 'Nintendo' } });
    fireEvent.change(costInput, { target: { value: '300' } });
    fireEvent.click(addButton);

    const { expenses, budget, remaining } = useContext(AppContext);

    expect(expenses.length).toBe(1);
    expect(expenses[0].name).toBe('Nintendo');
    expect(expenses[0].cost).toBe(300);

    expect(remaining).toBe(budget - 300);

    expect(budget).toBe(1000); 


    // const nameInput1 = screen.getByLabelText(/name/i);
    // const costInput1 = screen.getByLabelText(/cost/i);
    // const addButton1 = screen.getByRole('button', { name: /save/i });

    // fireEvent.change(nameInput1, { target: { value: 'Honda' } });
    // fireEvent.change(costInput1, { target: { value: '400' } });
    // fireEvent.click(addButton1);

    // const totalSpentText1 = screen.getByText(/spent so far/i).textContent;
    // const remainingText1 = screen.getByText(/remaining/i).textContent; 

    // const nameInput2 = screen.getByLabelText(/name/i);
    // const costInput2 = screen.getByLabelText(/cost/i);
    // const addButton2 = screen.getByRole('button', { name: /save/i });

    // fireEvent.change(nameInput2, { target: { value: 'Honey' } });
    // fireEvent.change(costInput2, { target: { value: '22' } });
    // fireEvent.click(addButton2);

    // const nameInput3 = screen.getByLabelText(/name/i);
    // const costInput3 = screen.getByLabelText(/cost/i);
    // const addButton3 = screen.getByRole('button', { name: /save/i });

    // fireEvent.change(nameInput3, { target: { value: 'Sasa' } });
    // fireEvent.change(costInput3, { target: { value: '100' } });
    // fireEvent.click(addButton3);



  })

}); 